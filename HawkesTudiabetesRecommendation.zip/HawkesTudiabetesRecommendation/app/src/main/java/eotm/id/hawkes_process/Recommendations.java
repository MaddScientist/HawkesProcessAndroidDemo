package eotm.id.hawkes_process;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

public class Recommendations extends Activity {

    static boolean fromRecommendations = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.recommendations);

        //Loading and displaying all posts for the selected user
        RecommendationListHelper recommendationAdapter = new RecommendationListHelper(this,UserListHelper.filteredAuthors, UserListHelper.filteredPosts, UserListHelper.filteredTimes, UserListHelper.filteredDiscussions);

        ListView list = (ListView)findViewById(android.R.id.list);

        list.setAdapter(recommendationAdapter);

    }



    public void back(View view) {


         fromRecommendations = true;
         Intent home = new Intent(this,Home.class);
         startActivity(home);




    }



}
