package eotm.id.hawkes_process;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;



public class UserListHelper extends ArrayAdapter<String> {


    private final Activity context;

    private String[] userIDs;

    private String[] recommendationCounts;


    //Current row view
    static View rowView=null;


    // track current row
    View curRow = null;


    String[] recommendedPosts = null;

    int keyIndex = -1;

    ArrayList<String> recommendationList = null;

    AlertDialog.Builder alertDialogBuilder;

    static String[] filteredPosts = null;

    static String[] filteredAuthors = null;

    static String[] filteredTimes = null;

    static String[] filteredDiscussions = null;




    public UserListHelper(Activity context, String[] userIDs) {

        super(context, R.layout.single_user, userIDs);

        this.context = context;

        this.userIDs = userIDs;




    }


    @Override
    public View getView(final int position, final View view, ViewGroup parent) {

        LayoutInflater inflater = context.getLayoutInflater();

        rowView = inflater.inflate(R.layout.single_user, null, true);

        TextView activityName = (TextView) rowView.findViewById(R.id.userID);
        activityName.setText(userIDs[position]);

        TextView recommendationCount = (TextView) rowView.findViewById(R.id.recommendationMessage);



        if ( Home.userToUser[position] != null) {

            String curUserId = "";

            int curRecommendationCount = 0;

            // will find total number of posts by all recommended authors for the current user
            for(int i=0; i < Home.userToUser[position].size(); i++) {

                curUserId = (String)Home.userToUser[position].get(i);


                Iterator it = Home.userPostMap.entrySet().iterator();

                //go through and found out how many posts the current author has
                while (it.hasNext()) {

                    Map.Entry pair = (Map.Entry)it.next();

                    String id = (String)pair.getKey();

                    if(id.equals(curUserId)) {

                        curRecommendationCount += (Integer)pair.getValue();


                    }

                }



            }


            if (curRecommendationCount < 2 ) {

                recommendationCount.setText(String.valueOf(curRecommendationCount) + " Recommended Post!");

            }
            else {

                recommendationCount.setText(String.valueOf(curRecommendationCount) + " Recommended Posts!");


            }


        }



        // When a user Id is selected , traverse each of that user's recommended authors and load all posts by each of those authors
        //Effectively displaying all recommended posts for the selected user

        rowView.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {


                recommendationList = new ArrayList<String>();



                String selectedUserId = userIDs[position];

                //Get Selected user index from map
                Iterator it = Home.userIndexIDMap.entrySet().iterator();
                while (it.hasNext()) {
                    Map.Entry pair = (Map.Entry)it.next();

                    if(pair.getValue().equals(selectedUserId)) {

                        keyIndex = (Integer)pair.getKey();


                        recommendationList = Home.userToUser[keyIndex];

                        // Show message if no recommendations were found for the selected user
                        if (recommendationList == null) {


                            alertDialogBuilder = new AlertDialog.Builder(context);

                            alertDialogBuilder
                                    .setMessage("No recommendations were found for this user")
                                    .setCancelable(false)
                                    .setPositiveButton("OK",new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog,int id) {


                                            dialog.cancel();

                                        }
                                    });

                            // create alert dialog
                            AlertDialog alertDialog = alertDialogBuilder.create();

                            // show it
                            alertDialog.show();


                        }

                        //load recommendations
                        else {

                            filteredPosts = null;

                            int commentCount = 0;

                            for(int i=0; i < Home.authors.length; i++) {


                                if ( Home.userToUser[keyIndex].contains(Home.authors[i])) {

                                    commentCount++;


                                }


                            }

                            int h = Home.userToUser[keyIndex].size();

                            String match = (String)Home.userToUser[keyIndex].get(0);

                            filteredPosts = new String[commentCount];

                            filteredAuthors = new String[commentCount];

                            filteredTimes = new String[commentCount];

                            filteredDiscussions = new String[commentCount];

                            int recommendationCount =0;

                            for(int j=0; j < Home.authors.length; j++) {


                                if ( Home.userToUser[keyIndex].contains(Home.authors[j])) {

                                    filteredPosts[recommendationCount] = Home.userPosts[j];

                                    filteredAuthors[recommendationCount] = Home.authors[j];

                                    filteredTimes[recommendationCount] = Home.times[j];

                                    filteredDiscussions[recommendationCount] = Home.rawdiscussionids[j];


                                    recommendationCount++;

                                }


                            }


                            //Home.list.setVisibility(View.GONE);

                            //UserListHelper postsAdapter = new UserListHelper(context,filteredPosts);

                           // Home.list.setAdapter(postsAdapter);

                           // Home.list.setVisibility(View.VISIBLE);


                            //go load and filter recommendations
                            Intent recommendations = new Intent(context,Recommendations.class);
                            context.startActivity(recommendations);


                        }




                    }

                }




            }

        });



        return rowView;


    }




    /******************************************************* Go Get Recommendations **********************************/


    // Will get all posts , then filter out those not from a recommending user
    // Accomplished by checking if author id is present in adjacent matrix of selected user


    private class RecommendationsDaemon extends AsyncTask<String, Void, String> {


        @Override
        protected String doInBackground(String... urls) {


            try {


                try {


                    HttpClient httpclient = new DefaultHttpClient();
                    HttpResponse response = null;

                    //TODO add authorID

                    HttpGet httpget = new HttpGet("http://m.indefinite-domain.com/tudiabetes/getRecommendations.php");
                    response = httpclient.execute(httpget);


                    HttpEntity httpEntity = response.getEntity();
                    InputStream is = httpEntity.getContent();


                    BufferedReader reader = new BufferedReader(new InputStreamReader(
                            is, "iso-8859-1"), 8);

                    StringBuilder sb = new StringBuilder();

                    String line = null;

                    while ((line = reader.readLine()) != null) {
                        sb.append(line + "\n");
                    }

                    is.close();

                    String jsonResponse = sb.toString();

                    //JSONObject jo = new JSONObject(jsonResponse);

                    JSONArray users = new JSONArray(jsonResponse);

                    int numOfUsers = users.length();

                    recommendedPosts = new String[numOfUsers];


                    for (int i = 0; i < numOfUsers; i++) {


                        recommendedPosts[i] = users.getJSONObject(i).getString("content");


                    }


                } catch (JSONException e) {

                    e.printStackTrace();

                }


            }
            /*catch (JSONException e) {

                e.printStackTrace();

            }*/ catch (ClientProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return "test";

        }

        @Override
        protected void onPostExecute(String result) {


            //UserListHelper userIdAdapter = new UserListHelper(Home.this,userIDs);

            //UserListHelper recommendationsAdapter = new UserListHelper(context,recommendedPosts);

            //Home.list.no

            //Home.list.setAdapter(recommendationsAdapter);



        }



    }


}
