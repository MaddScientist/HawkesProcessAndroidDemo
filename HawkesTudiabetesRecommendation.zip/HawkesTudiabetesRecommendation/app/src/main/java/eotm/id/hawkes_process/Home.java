package eotm.id.hawkes_process;

import android.app.Activity;
import android.content.res.AssetManager;
import android.os.AsyncTask;


import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;


public class Home extends Activity {


        File dir;

        File file;

        FileOutputStream os;

        static String[] userIDs = null;

        static String[] userPosts = null;

        static String[] authors = null;

        static String[] times = null;

        static String[] rawdiscussionids = null;

        static String[] rawdiscussions = null;


        Double[][] validUsers = null;

        // Will map each user's order index with their identification number
        static HashMap<Integer,String> userIndexIDMap = new HashMap<Integer,String>();

        static HashMap<String,Integer> userPostMap = new HashMap<String,Integer>();


        ArrayList<Float> rawAlphaEntries = new ArrayList<Float>();

        static ListView list = null;

        static ArrayList[] userToUser = null;

        AssetManager am = null;



    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);


        setContentView(R.layout.home);


        am = getAssets();



        if(!Recommendations.fromRecommendations) {

            //Go load all users from cloud database and map their IDs with their ordered indices, and map users to their posts
            UserDaemon userDaemon = new UserDaemon();
            userDaemon.execute();



        }

        else {


            UserListHelper userIdAdapter = new UserListHelper(Home.this,userIDs);

            list = (ListView)findViewById(android.R.id.list);

            list.setAdapter(userIdAdapter);

            Recommendations.fromRecommendations = false;

        }


        /*

        int validalphas = 0;


        try {



            InputStream is = am.open("alpha_pairs.txt");

            BufferedReader br = new BufferedReader(new InputStreamReader(is));

            String line = "";

            StringTokenizer st = null;

            String nextAlpha = "";

            //9443329

            int userCount = 0;


            while ( (line = br.readLine()) != null ) {

                userCount++;

                //new arraylist of recommendations for
                st = new StringTokenizer(line);

                while(st.hasMoreTokens()) {

                    nextAlpha = st.nextToken();


                    float v = Float.valueOf(nextAlpha);

                    if( v > 0 ) {

                        rawAlphaEntries.add(Float.valueOf(nextAlpha));



                        validalphas++;

                    }

                }


            }



        } catch (Exception e) {

            e.printStackTrace();

        }




        int k = rawAlphaEntries.size();

        //validalphas = 519656;

        //Finding the 70th percentile position in the list
        int keyIndex = (int) Math.ceil(.80 * validalphas); //TODO make validalphas a constant b/c it won't change b/c the dataset size isn't changing; corresponds to # of non-zero entries

        System.out.print(k);

        float marker = rawAlphaEntries.get(keyIndex-1);

        Collections.sort(rawAlphaEntries);

        //anything this or above is top 70%
        float alpha = rawAlphaEntries.get(keyIndex-1);

        System.out.println(alpha);

        */


    }



    //Retrieve and store all forum discussion titles from cloud database
    private class DiscussionDaemon extends AsyncTask<String, Void, String> {



        @Override
        protected String doInBackground(String... urls) {



            try {



                try {



                    HttpClient httpclient = new DefaultHttpClient();
                    HttpResponse response = null;

                    HttpGet httpget = new HttpGet("http://m.indefinite-domain.com/tudiabetes/getDiscussions.php");
                    response = httpclient.execute(httpget);


                    HttpEntity httpEntity = response.getEntity();
                    InputStream is = httpEntity.getContent();


                    BufferedReader reader = new BufferedReader(new InputStreamReader(
                            is, "iso-8859-1"), 8);

                    StringBuilder sb = new StringBuilder();

                    String line = null;

                    while ((line = reader.readLine()) != null) {
                        sb.append(line + "\n");
                    }

                    is.close();

                    String jsonResponse = sb.toString();

                    JSONArray posts = new JSONArray(jsonResponse);

                    int numOfDiscussions = posts.length();

                    rawdiscussions = new String[numOfDiscussions];


                    for(int i=0; i <= numOfDiscussions ; i++ ) {


                        rawdiscussions[i] = posts.getJSONObject(i).getString("title");



                    }



                }
                catch (JSONException e) {

                    e.printStackTrace();

                }


            }
            /*catch (JSONException e) {

                e.printStackTrace();

            }*/catch (ClientProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return "test";

        }

        @Override
        protected void onPostExecute(String result) {

            //Show list of all user ids and their number of recommendations found
            UserListHelper userIdAdapter = new UserListHelper(Home.this,userIDs);

            list = (ListView)findViewById(android.R.id.list);

            list.setAdapter(userIdAdapter);

            ProgressBar loading = (ProgressBar)findViewById(R.id.loading);
            loading.setVisibility(View.GONE);

            TextView loadingMessage = (TextView)findViewById(R.id.loadingMessage);
            loadingMessage.setVisibility(View.GONE);


        }


    }


    //Go load all users from cloud database and map their IDs with their ordered indices, and map users to their posts

    private class UserDaemon extends AsyncTask<String, Void, String> {



        @Override
        protected String doInBackground(String... urls) {



            try {



                try {



                    HttpClient httpclient = new DefaultHttpClient();
                    HttpResponse response = null;

                    HttpGet httpget = new HttpGet("http://m.indefinite-domain.com/tudiabetes/getUsers.php");
                    response = httpclient.execute(httpget);


                    HttpEntity httpEntity = response.getEntity();
                    InputStream is = httpEntity.getContent();


                    BufferedReader reader = new BufferedReader(new InputStreamReader(
                            is, "iso-8859-1"), 8);

                    StringBuilder sb = new StringBuilder();

                    String line = null;

                    while ((line = reader.readLine()) != null) {
                        sb.append(line + "\n");
                    }

                    is.close();

                    String jsonResponse = sb.toString();

                    //JSONObject jo = new JSONObject(jsonResponse);

                    JSONArray users = new JSONArray(jsonResponse);

                    int numOfUsers = users.length();

                    userIDs = new String[numOfUsers];


                    //Only sampling first 100 users
                    for(int i=0; i < numOfUsers; i++ ) {


                        userIDs[i] = users.getJSONObject(i).getString("user_id");

                        userIndexIDMap.put(i,userIDs[i]);

                        userPostMap.put(userIDs[i],0);


                    }

                    //adjacency matrix
                    userToUser = new ArrayList[numOfUsers];

                }
                catch (JSONException e) {

                    e.printStackTrace();

                }


            }
            /*catch (JSONException e) {

                e.printStackTrace();

            }*/catch (ClientProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return "test";

        }

        @Override
        protected void onPostExecute(String result) {



            //Retrieve and store all raw posts data from cloud database (i.e. authors, content, author post count, date/times, discussion parent, etc)
            PostsDaemon postsDaemon = new PostsDaemon();
            postsDaemon.execute();



        }


    }


    //Retrieve and store all raw posts data from cloud database (i.e. authors, content, author post count, date/times, discussion parent, etc)
    private class PostsDaemon extends AsyncTask<String, Void, String> {



        @Override
        protected String doInBackground(String... urls) {



            try {



                try {



                    HttpClient httpclient = new DefaultHttpClient();
                    HttpResponse response = null;

                    HttpGet httpget = new HttpGet("http://m.indefinite-domain.com/tudiabetes/getPosts.php");
                    response = httpclient.execute(httpget);


                    HttpEntity httpEntity = response.getEntity();
                    InputStream is = httpEntity.getContent();


                    BufferedReader reader = new BufferedReader(new InputStreamReader(
                            is, "iso-8859-1"), 8);

                    StringBuilder sb = new StringBuilder();

                    String line = null;

                    while ((line = reader.readLine()) != null) {
                        sb.append(line + "\n");
                    }

                    is.close();

                    String jsonResponse = sb.toString();

                    JSONArray posts = new JSONArray(jsonResponse);

                    int numOfPosts = posts.length();

                    userPosts = new String[numOfPosts];

                    authors = new String[numOfPosts];

                    times = new String[numOfPosts];

                    rawdiscussionids = new String[numOfPosts];


                    //Only sampling first 100 users
                    for(int i=0; i <= numOfPosts ; i++ ) {


                        userPosts[i] = posts.getJSONObject(i).getString("content");

                        authors[i] = posts.getJSONObject(i).getString("author");

                        times[i] = posts.getJSONObject(i).getString("rawdate");

                        rawdiscussionids[i] = posts.getJSONObject(i).getString("rawdiscussionid");

                        //tallying author posts, go through authorPostMap and update post count for current author
                        Iterator it = Home.userPostMap.entrySet().iterator();

                        while (it.hasNext()) {

                            Map.Entry pair = (Map.Entry)it.next();

                            String curUserId = (String)pair.getKey();

                            if(curUserId.equals(authors[i])) {

                                int curPostCount = (Integer)pair.getValue();
                                curPostCount++;
                                pair.setValue(curPostCount);


                            }

                        }





                    }



                }
                catch (JSONException e) {

                    e.printStackTrace();

                }


            }
            /*catch (JSONException e) {

                e.printStackTrace();

            }*/catch (ClientProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return "test";

        }

        @Override
        protected void onPostExecute(String result) {


            //Find recommended authors for each user by using the alpha similarity matrix learned from Hawkes Process
            // Construct adjacency matrix to store all recommendations
            findRecommendations();


        }


    }




    //Find recommended authors for each user by using the alpha similarity matrix learned from Hawkes Process
    // Construct adjacency matrix to store all recommendations
    private void findRecommendations() {


        // Building adjacency matrix

        try {

            InputStream is = am.open("alpha_pairs_100.txt"); // 100 x 100 sample space subset of Tudiabetes users from 3073 x 3073 superset

            BufferedReader br = new BufferedReader(new InputStreamReader(is));

            String line = "";

            StringTokenizer st = null;

            String nextAlpha = "";

            int x_axis=-1;

            int y_axis=-1;

            int rcount = 0;

            ArrayList<String> curList = null;

            while ( (line = br.readLine()) != null && rcount < 3 ) {

                // new fresh list of recommendations for current user row
                //note this curList of recommendations will only be added to user index if at least one entry is greater than alpha benchmark
                curList = new ArrayList<String>();

                x_axis++;

                st = new StringTokenizer(line);

                while(st.hasMoreTokens()) {


                    nextAlpha = st.nextToken();

                    y_axis++;


                    //.001563 was found to be the 80th percentile alpha value and used as benchmark
                    if(Float.valueOf(nextAlpha) >= .001563 ) {


                        String curXID = userIndexIDMap.get(x_axis);

                        String curYID = userIndexIDMap.get(y_axis);

                        //dont map user to themselves
                        if( !curYID.equals(curXID)) {

                            //add recommendation ( forum user ID) to current list of recommendations
                            curList.add(userIndexIDMap.get(y_axis));

                        }

                        System.out.println(curXID);



                    }



                }

                y_axis = -1; //after row is done, reset the y_axis


                //Add list of recommendations to current user iff list size > 0

                if(curList.size() >0) {

                    userToUser[x_axis] = curList;

                }



            }

        } catch (IOException e) {

            e.printStackTrace();

        }


        //Retrieve and store all forum discussion titles from cloud database database

        DiscussionDaemon discussionDaemon = new DiscussionDaemon();
        discussionDaemon.execute();




    }



    /**************************************************************************************************************/



}