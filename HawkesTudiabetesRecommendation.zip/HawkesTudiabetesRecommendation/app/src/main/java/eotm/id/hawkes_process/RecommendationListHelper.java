package eotm.id.hawkes_process;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;



public class RecommendationListHelper extends ArrayAdapter<String> {


    private final Activity context;

    private String[] authors;

    private String[] posts;

    private String[] times;

    private String[] discussions;


    //Current row view
    static View rowView=null;

    // track current row
    View curRow = null;




    public RecommendationListHelper(Activity context,String[] authors, String[] posts, String[] times, String[] discussions) {

        super(context, R.layout.single_recommendation, authors);

        this.context = context;

        this.posts = posts;

        this.authors = authors;

        this.times = times;

        this.discussions = discussions;



    }


    @Override
    public View getView(final int position, final View view, ViewGroup parent) {

        LayoutInflater inflater = context.getLayoutInflater();

        rowView = inflater.inflate(R.layout.single_recommendation, null, true);

        TextView author = (TextView) rowView.findViewById(R.id.author);
        author.setText("Author: " + authors[position]);

        TextView post = (TextView) rowView.findViewById(R.id.post);
        post.setText(posts[position]);

        TextView time = (TextView) rowView.findViewById(R.id.time);
        time.setText("Time: " + times[position]);

        TextView discussion = (TextView) rowView.findViewById(R.id.discussion);


        String discussion_title = Home.rawdiscussions[Integer.valueOf(discussions[position])-1];

        discussion.setText(discussion_title);


        return rowView;


    }



}
